
WannCannaBis – Termin- und Angebots-App

Start (Windows):
1) Node.js installieren: https://nodejs.org/
2) ZIP entpacken.
3) run_windows.bat starten.
4) Browser: http://localhost:3000

Admin:
- Login: /admin  (Standard: admin / admin1234!)
- Schlüssel erstellen: Code + Gültigkeitstage.
- Verkäufer müssen bei Registrierung den Schlüssel angeben. Zugang läuft zum Schlüssel-Ablauf aus.
